import { createContext, useContext, useEffect, useState } from 'react'
import {
  onAuthStateChanged, signInWithEmailAndPassword,
  signOut as firebaseSignOut,
} from 'firebase/auth'
import { auth } from '../firebase.js' // prepara as funcoes que serao utilizadas na tela

// E-mails que terão acesso de administrador
const ADMIN_EMAILS = ['admin@ituano.com', 'admin@admin.com']

const AuthContext = createContext(null) // permite compartilhar informacoes, sem precisar fazer manualmente

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (u) => {
      setUser(u)
      setLoading(false)
    })
    return unsub
  }, [])

  async function login(email, password) {
    return signInWithEmailAndPassword(auth, email, password)
  }

  async function logout() {
    return firebaseSignOut(auth)
  }

  // Papel do usuário logado
  const isAdmin = !!user && ADMIN_EMAILS.includes(user.email)
  const isUser = !!user
  const role = !user ? null : isAdmin ? 'admin' : 'user'

  return (
    <AuthContext.Provider value={{ user, loading, login, logout, isAdmin, isUser, role }}>
      {children}
    </AuthContext.Provider>
  )
} // o AuthProvider controla o login, logout, estado da sessao e permissoes dos usuarios, compartilha com o sistema

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth deve ser usado dentro de AuthProvider')
  return ctx
} // o useAuth() facilita o acesso aos dados do usuario logado e as funcoes de autenticacao, evitando repeticao