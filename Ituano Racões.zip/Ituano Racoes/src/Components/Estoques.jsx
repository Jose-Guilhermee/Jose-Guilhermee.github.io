import { useEffect, useState } from 'react'
import {
  addDoc, collection, deleteDoc, doc, getDocs, updateDoc,
} from 'firebase/firestore'
import { db } from '../firebase.js'
import { useAuth } from '../Context/AuthContext.jsx' // prepara as funcoes que serao utilizadas na tela

const COL = 'estoques'
const EMPTY = { produto: '', lote: '', quantidade: '', validade: '', status: 'disponivel' }
const STATUS = ['disponivel', 'reservado', 'vencido', 'esgotado'] // define onde os dados serao guardados

export default function Estoques() {
  const { isAdmin } = useAuth()
  const [items, setItems] = useState([])
  const [form, setForm] = useState(EMPTY)
  const [editId, setEditId] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('') // organiza as variaveis que serao utilizadas na tela

  async function load() {
    setLoading(true)
    try {
      const snap = await getDocs(collection(db, COL))
      setItems(snap.docs.map((d) => ({ id: d.id, ...d.data() })))
      setError('')
    } catch {
      setError('Erro ao carregar estoques. Verifique as regras do Firestore.')
    } finally {
      setLoading(false)
    }
  } // ele consulta os produtos no fb, armazena os dados e trata possiveis erros
   
  useEffect(() => { load() }, []) // permite carregar produtos automaticamnete

  async function handleSubmit(e) {
    e.preventDefault()
    if (!isAdmin) { setError('Apenas administradores podem cadastrar/editar.'); return }
    try {
      const payload = { ...form, quantidade: Number(form.quantidade) }
      if (editId) await updateDoc(doc(db, COL, editId), payload)
      else await addDoc(collection(db, COL), payload)
      setForm(EMPTY); setEditId(null); setError(''); load()
    } catch { setError('Erro ao salvar. Tente novamente.') }
  } // controla todo processo para adicionar produtos

  function handleEdit(item) {
    if (!isAdmin) { setError('Apenas administradores podem editar.'); return }
    setEditId(item.id)
    setForm({
      produto: item.produto ?? '', lote: item.lote ?? '',
      quantidade: item.quantidade ?? '', validade: item.validade ?? '',
      status: item.status ?? 'disponivel',
    })
  } // verifica o usuario e permite editar um produto existente

  async function handleDelete(id) {
    if (!isAdmin) { setError('Apenas administradores podem excluir.'); return }
    if (!confirm('Tem certeza que deseja excluir este estoque?')) return
    await deleteDoc(doc(db, COL, id)); load()
  } //verifica permissao, excluiu o produto pelo id e recarrega a lista

  return (
    <div>
      <div className="panel-head">
        <h2>Estoques</h2>
        <span className="muted">{items.length} item(ns)</span>
      </div>

      {error && <div className="alert alert-error">{error}</div>}

      <div className="panel">
        <form className="form" onSubmit={handleSubmit}>
          <label>Produto
            <input value={form.produto} onChange={(e) => setForm({ ...form, produto: e.target.value })} required />
          </label>
          <label>Lote
            <input value={form.lote} onChange={(e) => setForm({ ...form, lote: e.target.value })} required />
          </label>
          <label>Quantidade
            <input type="number" value={form.quantidade} onChange={(e) => setForm({ ...form, quantidade: e.target.value })} required />
          </label>
          <label>Validade
            <input type="date" value={form.validade} onChange={(e) => setForm({ ...form, validade: e.target.value })} />
          </label>
          <label>Status
            <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })}>
              {STATUS.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </label>
          <div className="actions">
            <button type="submit" className="btn btn-primary">{editId ? 'Salvar' : 'Cadastrar'}</button>
            {editId && <button type="button" className="btn" onClick={() => { setEditId(null); setForm(EMPTY) }}>Cancelar</button>}
          </div>
        </form>
      </div>

      <div className="panel">
        {loading ? <p>Carregando…</p> : items.length === 0 ? <p className="muted">Nenhum estoque cadastrado.</p> : (
          <div className="tableWrap">
            <table>
              <thead>
                <tr><th>Produto</th><th>Lote</th><th>Qtd</th><th>Validade</th><th>Status</th><th>Ações</th></tr>
              </thead>
              <tbody>
                {items.map((i) => (
                  <tr key={i.id}>
                    <td><strong>{i.produto}</strong></td>
                    <td>{i.lote}</td>
                    <td>{i.quantidade}</td>
                    <td>{i.validade}</td>
                    <td><span className={`status status-${i.status}`}>{i.status}</span></td>
                    <td>
                      <div className="rowActions">
                        <button className="btn btn-sm" onClick={() => handleEdit(i)} disabled={!isAdmin}>Editar</button>
                        <button className="btn btn-sm btn-danger" onClick={() => handleDelete(i.id)} disabled={!isAdmin}>Excluir</button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )
}