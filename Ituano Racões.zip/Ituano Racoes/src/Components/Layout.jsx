import { useAuth } from '../Context/AuthContext.jsx' // prepara as funcoes que serao utilizadas na tela

const TABS = [
  { key: 'dashboard', label: 'Dashboard', adminOnly: true },
  { key: 'vitrine', label: 'Vitrine' },
  { key: 'produtos', label: 'Produtos', adminOnly: true },
  { key: 'pedidos', label: 'Pedidos', adminOnly: true },
  { key: 'categorias', label: 'Categorias', adminOnly: true },
  { key: 'estoques', label: 'Estoques', adminOnly: true },
  { key: 'avaliacoes', label: 'Avaliações', adminOnly: true },
] // organiza as abas de navegacao e indica quais sao restritas(verifica permissao nas regras do fb)

export default function Layout({ tab, setTab, children }) {
  const { user, logout, isAdmin } = useAuth() // organiza a estrutura visual, verifica o usuario e permite que encerre a sessao 

  const abasVisiveis = TABS.filter((t) => isAdmin || !t.adminOnly) // controla a exibicao de interface conforme o usuario

  return (
    <div className="app">
      <header>
        <div className="header-left">
          <div>
            <h1>Ituano Rações</h1>
            <p>Controle de Estoque</p>
          </div>
        </div>

        <div className="header-right">
          <div className="user-info">
            <span className={`badge ${isAdmin ? 'badge-admin' : 'badge-user'}`}>
              {isAdmin ? 'Administrador' : 'Usuário'}
            </span>
            <span className="user-email">{user?.email}</span>
          </div>
          <button className="btn btn-ghost" onClick={logout}>Sair</button>
        </div>
      </header>

      {/* Com uma única aba (usuário comum), a barra não é necessária */}
      {abasVisiveis.length > 1 && (
        <nav className="tabs">
          {abasVisiveis.map((t) => (
            <button
              key={t.key}
              className={tab === t.key ? 'active' : ''}
              onClick={() => setTab(t.key)}
            >
              {t.label}
            </button>
          ))}
        </nav>
      )}

      <main className="content" style={abasVisiveis.length > 1 ? undefined : { marginTop: 20 }}>
        {children}
      </main>

      <footer className="footer">
        <span>Ituano Rações © {new Date().getFullYear()}</span>
        <span>Sistema CRUD · React + Vite + Firebase</span>
      </footer>
    </div>
  )
}
