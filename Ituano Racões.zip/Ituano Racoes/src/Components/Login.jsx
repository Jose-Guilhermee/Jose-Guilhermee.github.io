import { useState } from 'react'
import { useAuth } from '../Context/AuthContext.jsx' // prepara as funcoes que serao utilizadas na tela

export default function Login() {
  const { login } = useAuth()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false) // organiza as variaveis que serao utilizadas na tela

  async function handleSubmit(e) {
    e.preventDefault()
    setError('')
    setLoading(true)
    try {
      await login(email.trim(), password)
    } catch (err) {
      const msg =
        err.code === 'auth/invalid-credential'
          ? 'E-mail ou senha inválidos.'
          : err.code === 'auth/user-not-found'
          ? 'Usuário não encontrado.'
          : err.code === 'auth/wrong-password'
          ? 'Senha incorreta.'
          : err.code === 'auth/too-many-requests'
          ? 'Muitas tentativas. Tente novamente mais tarde.'
          : 'Não foi possível entrar. Verifique os dados.'
      setError(msg)
    } finally {
      setLoading(false)
    }
  } // verifica o usuário, trata possíveis erros e controla o carregamento do login.

  return (
    <div className="login-wrapper">
      <div className="login-card">
        <div className="login-brand">
          <h1>Ituano Rações</h1>
          <p>Controle de Estoque</p>
        </div>

        <form onSubmit={handleSubmit} className="login-form">
          <label>
            E-mail
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="voce@exemplo.com"
              autoComplete="email"
              required
            />
          </label>
          <label>
            Senha
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              autoComplete="current-password"
              required
            />
          </label>

          {error && <div className="alert alert-error">{error}</div>}

          <button type="submit" className="btn btn-primary btn-block" disabled={loading}>
            {loading ? 'Entrando…' : 'Entrar'}
          </button>
        </form>

        <div className="login-hint">
          <strong>Contas de teste:</strong>
          <span>admin@ituano.com / admin123 (Administrador)</span>
          <span>usuario@ituano.com / usuario123 (Usuário comum)</span>
        </div>
      </div>
    </div>
  )
}