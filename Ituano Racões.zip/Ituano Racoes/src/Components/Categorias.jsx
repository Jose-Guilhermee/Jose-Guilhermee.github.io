import { useEffect, useState } from 'react'
import {
  addDoc, collection, deleteDoc, doc, getDocs, updateDoc,
} from 'firebase/firestore'
import { db } from '../firebase.js'
import { useAuth } from '../Context/AuthContext.jsx' // prepara as funcoes que serao utilizadas na tela

const COL = 'categorias'
const EMPTY = { nome: '', descricao: '', faixa_preco: '', publico: '', status: 'ativa' }
const STATUS = ['ativa', 'inativa']
const PUBLICO = ['infantil', 'juvenil', 'adulto', 'unissex', 'todos'] // define onde os dados serao guardados

export default function Categorias() {
  const { isAdmin } = useAuth()
  const [items, setItems] = useState([])
  const [form, setForm] = useState(EMPTY)
  const [editId, setEditId] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('') // organiza as variaveis que serao utilizadas na tela

  async function load() {
    setLoading(true)
    try {
      const snap = await getDocs(collection(db, COL))
      setItems(snap.docs.map((d) => ({ id: d.id, ...d.data() })))
      setError('')
    } catch {
      setError('Erro ao carregar categorias. Verifique as regras do Firestore.')
    } finally {
      setLoading(false)
    }
  } // ele consulta os produtos no fb, armazena os dados e trata possiveis erros

  useEffect(() => { load() }, []) // permite carregar produtos automaticamnete

  async function handleSubmit(e) {
    e.preventDefault()
    if (!isAdmin) { setError('Apenas administradores podem cadastrar/editar.'); return }
    try {
      if (editId) await updateDoc(doc(db, COL, editId), form)
      else await addDoc(collection(db, COL), form)
      setForm(EMPTY); setEditId(null); setError(''); load()
    } catch { setError('Erro ao salvar. Tente novamente.') }
  } // controla todo processo para adicionar produtos

  function handleEdit(item) {
    if (!isAdmin) { setError('Apenas administradores podem editar.'); return }
    setEditId(item.id)
    setForm({
      nome: item.nome ?? '', descricao: item.descricao ?? '',
      faixa_preco: item.faixa_preco ?? '', publico: item.publico ?? '',
      status: item.status ?? 'ativa',
    })
  } // verifica o usuario e permite editar um produto existente

  async function handleDelete(id) {
    if (!isAdmin) { setError('Apenas administradores podem excluir.'); return }
    if (!confirm('Tem certeza que deseja excluir esta categoria?')) return
    await deleteDoc(doc(db, COL, id)); load()
  } //verifica permissao, excluiu o produto pelo id e recarrega a lista

  return (
    <div>
      <div className="panel-head">
        <h2>Categorias</h2>
        <span className="muted">{items.length} item(ns)</span>
      </div>

      {error && <div className="alert alert-error">{error}</div>}

      <div className="panel">
        <form className="form" onSubmit={handleSubmit}>
          <label>Nome
            <input value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} required />
          </label>
          <label>Descrição
            <input value={form.descricao} onChange={(e) => setForm({ ...form, descricao: e.target.value })} />
          </label>
          <label>Faixa de preço
            <input placeholder="ex: 50-200" value={form.faixa_preco} onChange={(e) => setForm({ ...form, faixa_preco: e.target.value })} />
          </label>
          <label>Público
            <select value={form.publico} onChange={(e) => setForm({ ...form, publico: e.target.value })}>
              <option value="">Selecione…</option>
              {PUBLICO.map((p) => <option key={p} value={p}>{p}</option>)}
            </select>
          </label>
          <label>Status
            <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })}>
              {STATUS.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </label>
          <div className="actions">
            <button type="submit" className="btn btn-primary">{editId ? 'Salvar' : 'Cadastrar'}</button>
            {editId && <button type="button" className="btn" onClick={() => { setEditId(null); setForm(EMPTY) }}>Cancelar</button>}
          </div>
        </form>
      </div>

      <div className="panel">
        {loading ? <p>Carregando…</p> : items.length === 0 ? <p className="muted">Nenhuma categoria cadastrada.</p> : (
          <div className="tableWrap">
            <table>
              <thead>
                <tr><th>Nome</th><th>Descrição</th><th>Faixa</th><th>Público</th><th>Status</th><th>Ações</th></tr>
              </thead>
              <tbody>
                {items.map((i) => (
                  <tr key={i.id}>
                    <td><strong>{i.nome}</strong></td>
                    <td>{i.descricao}</td>
                    <td>{i.faixa_preco}</td>
                    <td>{i.publico}</td>
                    <td><span className={`status status-${i.status}`}>{i.status}</span></td>
                    <td>
                      <div className="rowActions">
                        <button className="btn btn-sm" onClick={() => handleEdit(i)} disabled={!isAdmin}>Editar</button>
                        <button className="btn btn-sm btn-danger" onClick={() => handleDelete(i.id)} disabled={!isAdmin}>Excluir</button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )
}