import { useEffect, useState } from 'react'
import { collection, getDocs } from 'firebase/firestore'
import { db } from '../firebase.js'
import ImagemProduto from './ImagemProduto.jsx'
import './Vitrine.css' // prepara as funcoes que serao utilizadas na tela

// Remove acentos e maiúsculas para a busca
const normalizar = (t) =>
  String(t ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim()

// Disponível = não esgotado e com estoque maior que zero
const disponivel = (p) => p.status !== 'esgotado' && Number(p.estoque) > 0

export default function Vitrine() {
  const [produtos, setProdutos] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [busca, setBusca] = useState('')
  const [categoria, setCategoria] = useState('') // organiza as variaveis que serao utilizadas na tela

  useEffect(() => {
    async function load() {
      try {
        const snap = await getDocs(collection(db, 'produtos'))
        const lista = snap.docs
          .map((d) => ({ id: d.id, ...d.data() }))
          .filter((p) => p.status !== 'inativo') // inativos não aparecem
          .sort((a, b) => String(a.nome ?? '').localeCompare(String(b.nome ?? '')))
        setProdutos(lista)
      } catch {
        setError('Erro ao carregar a vitrine. Verifique as regras do Firestore.')
      } finally {
        setLoading(false)
      }
    }
    load()
  }, []) // busca os dados no fb, remove os p inativos, ordena alfabeticamente e exibe a lista

  const categorias = [...new Set(produtos.map((p) => p.categoria).filter(Boolean))].sort() // extrais as categorias e remove as repetidas para o filtro

  const filtrados = produtos.filter((p) =>
    normalizar(p.nome).includes(normalizar(busca)) &&
    (!categoria || p.categoria === categoria)
  ) // exibe os produtos pesquisado e que pertence a categoria selecionada

  return (
    <div>
      <div className="panel-head">
        <h2>Vitrine</h2>
        <span className="muted">{filtrados.length} produto(s)</span>
      </div>

      {error && <div className="alert alert-error">{error}</div>}

      <div className="panel">
        <div className="form vitrine-filtros">
          <label>Buscar por nome
            <input
              type="search"
              placeholder="ex: ração premium"
              value={busca}
              onChange={(e) => setBusca(e.target.value)}
            />
          </label>
          <label>Categoria
            <select value={categoria} onChange={(e) => setCategoria(e.target.value)}>
              <option value="">Todas</option>
              {categorias.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </label>
        </div>
      </div>

      {loading ? (
        <div className="panel"><p>Carregando…</p></div>
      ) : filtrados.length === 0 ? (
        <div className="panel"><p className="muted">Nenhum produto encontrado.</p></div>
      ) : (
        <div className="vitrine-grid">
          {filtrados.map((p) => {
            const ok = disponivel(p)
            return (
              <article key={p.id} className="produto-card">
                <div className="produto-img-wrap">
                  <ImagemProduto src={p.imagem} alt={p.nome} />
                  <span className={`produto-tag ${ok ? 'tag-ok' : 'tag-off'}`}>
                    {ok ? 'Disponível' : 'Esgotado'}
                  </span>
                </div>
                <div className="produto-info">
                  <h3>{p.nome}</h3>
                  <span className="muted">{p.categoria || 'Sem categoria'}</span>
                  <strong className="produto-preco">R$ {Number(p.preco || 0).toFixed(2)}</strong>
                </div>
              </article>
            )
          })}
        </div>
      )}
    </div>
  )
}
