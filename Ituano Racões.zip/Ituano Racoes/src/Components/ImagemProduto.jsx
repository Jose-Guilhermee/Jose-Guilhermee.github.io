import { useState } from 'react'
import './Vitrine.css' // prepara as funcoes que serao utilizadas na tela

// Mostra a imagem do produto ou um espaço "Sem imagem"
// (quando não há imagem ou o link está quebrado)
export default function ImagemProduto({ src, alt = '', className = '' }) {
  // Guarda o link que falhou; se o link mudar, tenta carregar de novo
  const [falhou, setFalhou] = useState('')

  if (!src || falhou === src) {
    return <div className={`img-produto img-vazia ${className}`}>Sem imagem</div>
  }

  return (
    <img
      className={`img-produto ${className}`}
      src={src}
      alt={alt}
      loading="lazy"
      onError={() => setFalhou(src)}
    />
  )
}
