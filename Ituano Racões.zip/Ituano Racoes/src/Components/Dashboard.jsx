import { useEffect, useState } from 'react'
import { collection, getDocs } from 'firebase/firestore'
import { db } from '../firebase.js' // prepara as funcoes que serao utilizadas na tela

const COLS = ['produtos', 'pedidos', 'categorias', 'estoques', 'avaliacoes'] // organiza as colecoes do fb em um array

export default function Dashboard({ onNavigate }) {
  const [data, setData] = useState({})
  const [loading, setLoading] = useState(true) // useState permite guardar informacoes que podem mudar

  useEffect(() => {
    async function loadAll() {
      const result = {}
      for (const col of COLS) {
        const snap = await getDocs(collection(db, col))
        result[col] = snap.docs.map((d) => ({ id: d.id, ...d.data() }))
      }
      setData(result)
      setLoading(false)
    }
    loadAll()
  }, []) // executa a rotina de carregamentos, percorrendo as colecoes e buscando os documentos para atualizar

  if (loading) {
    return <div className="panel"><p>Carregando dashboard…</p></div>
  } // o if impede que o dashboard seja exibido antes do carregamento dos dados

  const produtos = data.produtos || []
  const pedidos = data.pedidos || []
  const categorias = data.categorias || []
  const estoques = data.estoques || []
  const avaliacoes = data.avaliacoes || []

  const totalEstoque = produtos.reduce((s, p) => s + (Number(p.estoque) || 0), 0)
  const valorEstoque = produtos.reduce((s, p) => s + (Number(p.preco) || 0) * (Number(p.estoque) || 0), 0)
  const receita = pedidos
    .filter((p) => ['pago', 'enviado', 'entregue'].includes(p.status))
    .reduce((s, p) => s + (Number(p.valor_total) || 0), 0)
  const pedidosPendentes = pedidos.filter((p) => p.status === 'pendente').length
  const notaMedia = avaliacoes.length
    ? (avaliacoes.reduce((s, a) => s + (Number(a.nota) || 0), 0) / avaliacoes.length).toFixed(1)
    : '—'
  const produtosEsgotados = produtos.filter((p) => p.status === 'esgotado' || Number(p.estoque) === 0).length

  const kpis = [ // indicador-chave de desempenho
    { label: 'Produtos', value: produtos.length, color: 'blue', tab: 'produtos' },
    { label: 'Pedidos', value: pedidos.length, color: 'green', tab: 'pedidos' },
    { label: 'Categorias', value: categorias.length, color: 'purple', tab: 'categorias' },
    { label: 'Estoques', value: estoques.length, color: 'orange', tab: 'estoques' },
    { label: 'Avaliações', value: avaliacoes.length, color: 'yellow', tab: 'avaliacoes' },
  ] // calcula os dados do fb, soma os valores, o array kpis organiza os inidcadores exibidos

  return (
    <div>
      <h2 className="section-title">Visão Geral</h2>

      <div className="kpi-grid">
        {kpis.map((k) => (
          <button
            key={k.label}
            className={`kpi-card kpi-${k.color}`}
            onClick={() => onNavigate(k.tab)}
          >
            <div className="kpi-icon">{k.icon}</div>
            <div className="kpi-value">{k.value}</div>
            <div className="kpi-label">{k.label}</div>
          </button>
        ))}
      </div>

      <div className="two-col">
        <div className="panel">
          <h3>Financeiro</h3>
          <ul className="stat-list">
            <li><span>Receita confirmada</span><strong>R$ {receita.toFixed(2)}</strong></li>
            <li><span>Pedidos pendentes</span><strong>{pedidosPendentes}</strong></li>
            <li><span>Valor em estoque</span><strong>R$ {valorEstoque.toFixed(2)}</strong></li>
          </ul>
        </div>

        <div className="panel">
          <h3>Indicadores</h3>
          <ul className="stat-list">
            <li><span>Unidades em estoque</span><strong>{totalEstoque}</strong></li>
            <li><span>Produtos esgotados</span><strong>{produtosEsgotados}</strong></li>
            <li><span>Nota média</span><strong>{notaMedia}</strong></li>
          </ul>
        </div>
      </div>

      <div className="panel">
        <h3>Últimos pedidos</h3>
        {pedidos.length === 0 ? (
          <p className="muted">Nenhum pedido cadastrado.</p>
        ) : (
          <div className="tableWrap">
            <table>
              <thead>
                <tr>
                  <th>Produto</th><th>Comprador</th><th>Data</th>
                  <th>Valor</th><th>Status</th>
                </tr>
              </thead>
              <tbody>
                {[...pedidos]
                  .sort((a, b) => (b.data || '').localeCompare(a.data || ''))
                  .slice(0, 5)
                  .map((p) => (
                    <tr key={p.id}>
                      <td>{p.produto}</td>
                      <td>{p.comprador}</td>
                      <td>{p.data}</td>
                      <td>R$ {Number(p.valor_total || 0).toFixed(2)}</td>
                      <td><span className={`status status-${p.status}`}>{p.status}</span></td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )
}