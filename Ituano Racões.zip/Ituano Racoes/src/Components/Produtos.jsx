import { useEffect, useState } from 'react'
import {
  addDoc, collection, deleteDoc, doc, getDocs, updateDoc,
} from 'firebase/firestore'
import { db } from '../firebase.js'
import { useAuth } from '../Context/AuthContext.jsx'
import ImagemProduto from './ImagemProduto.jsx'
import { reduzirImagem } from '../utils/imagem.js'
import './Vitrine.css' // prepara as funcoes que serao utilizadas na tela

const COL = 'produtos'
const EMPTY = { nome: '', categoria: '', preco: '', estoque: '', status: 'ativo', imagem: '' }
const STATUS = ['ativo', 'inativo', 'esgotado']
const ehBase64 = (v) => typeof v === 'string' && v.startsWith('data:') // define onde os dados serao guardados

export default function Produtos() {
  const { isAdmin } = useAuth()
  const [items, setItems] = useState([])
  const [form, setForm] = useState(EMPTY)
  const [editId, setEditId] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [fileKey, setFileKey] = useState(0) // organiza as variaveis que serao utilizadas na tela

  async function load() {
    setLoading(true)
    try {
      const snap = await getDocs(collection(db, COL))
      setItems(snap.docs.map((d) => ({ id: d.id, ...d.data() })))
      setError('')
    } catch (e) {
      setError('Erro ao carregar produtos. Verifique as regras do Firestore.')
    } finally {
      setLoading(false)
    }
  } // ele consulta os produtos no fb, armazena os dados e trata possiveis erros

  useEffect(() => { load() }, []) // permite carregar produtos automaticamnete

  function limparForm() {
    setForm(EMPTY); setEditId(null); setFileKey((k) => k + 1)
  } // prepara para um novo cadastro

  async function handleSubmit(e) {
    e.preventDefault()
    if (!isAdmin) {
      setError('Apenas administradores podem cadastrar/editar.')
      return
    }
    try {
      const payload = {
        ...form,
        preco: Number(form.preco),
        estoque: Number(form.estoque),
        imagem: form.imagem.trim(),
      }
      if (editId) 
        await updateDoc(doc(db, COL, editId), payload)
      else 
        await addDoc(collection(db, COL), payload)
      limparForm(); setError(''); load()
    } catch {
        setError('Erro ao salvar. Tente novamente.')
    }
  } // controla todo processo para adicionar produtos 

  // Escolher arquivo: reduz para 500px e guarda em base64
  async function handleFile(e) {
    const arquivo = e.target.files?.[0]
    if (!arquivo) return
    try {
      const dataUrl = await reduzirImagem(arquivo, 500)
      // O Firestore limita o documento a 1 MB
      if (dataUrl.length > 700000) {
        setError('Imagem muito grande mesmo após reduzir. Escolha outra.')
        setFileKey((k) => k + 1)
        return
      }
      setForm((f) => ({ ...f, imagem: dataUrl }))
      setError('')
    } catch (err) {
      setError(err.message || 'Erro ao processar a imagem.')
      setFileKey((k) => k + 1)
    }
  } // verifica os padroes da imagem escolhida

  function removerImagemForm() {
    setForm((f) => ({ ...f, imagem: '' }))
    setFileKey((k) => k + 1)
  } // remove a imagem e permite colocar outra

  async function handleRemoverImagem(id) {
    if (!isAdmin) { setError('Apenas administradores podem editar.'); return }
    if (!confirm('Remover a imagem deste produto?')) return
    try {
      await updateDoc(doc(db, COL, id), { imagem: '' })
      if (editId === id) removerImagemForm()
      load()
    } catch {
      setError('Erro ao remover a imagem.')
    }
  } // verifica o usuario e remove a imagem da tabela do banco

  function handleEdit(item) {
    if (!isAdmin) { setError('Apenas administradores podem editar.'); return }
    setEditId(item.id)
    setFileKey((k) => k + 1)
    setForm({
      nome: item.nome ?? '', categoria: item.categoria ?? '',
      preco: item.preco ?? '', estoque: item.estoque ?? '',
      status: item.status ?? 'ativo',
      imagem: item.imagem ?? '', 
    })
  } // verifica o usuario e permite editar um produto existente

  async function handleDelete(id) {
    if (!isAdmin) { setError('Apenas administradores podem excluir.'); return }
    if (!confirm('Tem certeza que deseja excluir este produto?')) return
    await deleteDoc(doc(db, COL, id)); 
    load()
  } //verifica permissao, excluiu o produto pelo id e recarrega a lista

  return (
    <div>
      <div className="panel-head">
        <h2>Produtos</h2>
        <span className="muted">{items.length} item(ns)</span>
      </div>

      {error && <div className="alert alert-error">{error}</div>}

      <div className="panel">
        <form className="form" onSubmit={handleSubmit}>
          <label>Nome
            <input value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} required />
          </label>
          <label>Categoria
            <input value={form.categoria} onChange={(e) => setForm({ ...form, categoria: e.target.value })} required />
          </label>
          <label>Preço
            <input type="number" step="0.01" value={form.preco} onChange={(e) => setForm({ ...form, preco: e.target.value })} required />
          </label>
          <label>Estoque
            <input type="number" value={form.estoque} onChange={(e) => setForm({ ...form, estoque: e.target.value })} required />
          </label>
          <label>Status
            <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })}>
              {STATUS.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </label>

          <div className="campo-imagem">
            <label>Imagem (link ou arquivo)
              <div className="imagem-controles">
                <input
                  type="text"
                  placeholder={ehBase64(form.imagem) ? 'Arquivo carregado' : 'https://…/imagem.jpg'}
                  value={ehBase64(form.imagem) ? '' : form.imagem}
                  onChange={(e) => setForm({ ...form, imagem: e.target.value })}
                />
                <input key={fileKey} type="file" accept="image/*" onChange={handleFile} />
              </div>
            </label>
            {form.imagem && (
              <div className="imagem-previa">
                <ImagemProduto className="thumb" src={form.imagem} alt="Prévia" />
                <button type="button" className="btn btn-sm btn-danger" onClick={removerImagemForm}>
                  Remover imagem
                </button>
              </div>
            )}
          </div>

          <div className="actions">
            <button type="submit" className="btn btn-primary">{editId ? 'Salvar' : 'Cadastrar'}</button>
            {editId && <button type="button" className="btn" onClick={limparForm}>Cancelar</button>}
          </div>
        </form>
      </div>

      <div className="panel">
        {loading ? <p>Carregando…</p> : items.length === 0 ? <p className="muted">Nenhum produto cadastrado.</p> : (
          <div className="tableWrap">
            <table>
              <thead>
                <tr><th>Imagem</th><th>Nome</th><th>Categoria</th><th>Preço</th><th>Estoque</th><th>Status</th><th>Ações</th></tr>
              </thead>
              <tbody>
                {items.map((i) => (
                  <tr key={i.id}>
                    <td><ImagemProduto className="thumb" src={i.imagem} alt={i.nome} /></td>
                    <td><strong>{i.nome}</strong></td>
                    <td>{i.categoria}</td>
                    <td>R$ {Number(i.preco || 0).toFixed(2)}</td>
                    <td>{i.estoque}</td>
                    <td><span className={`status status-${i.status}`}>{i.status}</span></td>
                    <td>
                      <div className="rowActions">
                        <button className="btn btn-sm" onClick={() => handleEdit(i)} disabled={!isAdmin}>Editar</button>
                        {i.imagem && (
                          <button className="btn btn-sm" onClick={() => handleRemoverImagem(i.id)} disabled={!isAdmin}>Remover img</button>
                        )}
                        <button className="btn btn-sm btn-danger" onClick={() => handleDelete(i.id)} disabled={!isAdmin}>Excluir</button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )
}
