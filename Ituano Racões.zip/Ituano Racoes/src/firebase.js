import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyC_NtlPtM_1brIxP5siIbXC6U_2Ny6eLSw",
  authDomain: "ituano-racoes.firebaseapp.com",
  projectId: "ituano-racoes",
  storageBucket: "ituano-racoes.firebasestorage.app",
  messagingSenderId: "796347002255",
  appId: "1:796347002255:web:d31149a0ff27a1f0f6affa",
  measurementId: "G-R0EE4MJ5QH"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
export const auth = getAuth(app);