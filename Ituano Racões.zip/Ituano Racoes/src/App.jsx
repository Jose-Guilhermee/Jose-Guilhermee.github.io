import { useState } from 'react'
import { AuthProvider, useAuth } from './Context/AuthContext.jsx'
import Login from './Components/Login.jsx'
import Layout from './Components/Layout.jsx'
import Dashboard from './Components/Dashboard.jsx'
import Vitrine from './Components/Vitrine.jsx'
import Produtos from './Components/Produtos.jsx'
import Pedidos from './Components/Pedidos.jsx'
import Categorias from './Components/Categorias.jsx'
import Estoques from './Components/Estoques.jsx'
import Avaliacoes from './Components/Avaliacoes.jsx' //os imports conectam os diferentes componentes e funcionalidades do sistema

const VIEWS = {
  dashboard: Dashboard,
  vitrine: Vitrine,
  produtos: Produtos,
  pedidos: Pedidos,
  categorias: Categorias,
  estoques: Estoques,
  avaliacoes: Avaliacoes,
} // organiza a tela dos sistemas para saber qual componente exibir

function Shell() {
  const { user, loading, isAdmin } = useAuth()
  const [tab, setTab] = useState('dashboard')

  if (loading) {
    return <div className="loading-screen">Carregando…</div>
  }

  if (!user) {
    return <Login />
  }

  // Usuário comum só enxerga a Vitrine; qualquer outra aba volta para ela
  const tabAtual = isAdmin && VIEWS[tab] ? tab : 'vitrine'
  const Component = VIEWS[tabAtual]

  return (
    <Layout tab={tabAtual} setTab={(t) => setTab(isAdmin ? t : 'vitrine')}>
      {tabAtual === 'dashboard'
        ? <Dashboard onNavigate={setTab} />
        : <Component />}
    </Layout>
  )
} // a funcao Shell() controla a navegacao, verifica o usuario e direciona para a tela permitida

export default function App() {
  return (
    <AuthProvider>
      <Shell />
    </AuthProvider>
  )
} // o App() com o AuthProvider inicia o Shell e compartilha as informacoes de autenticacao
