# Sistema CRUD React + Vite + Firebase Firestore

## 1. Criar o projeto
Você pode usar esta pasta diretamente. Execute:
npm install
npm run dev

## 2. Configurar o Firebase
1. Acesse o Firebase Console.
2. Crie um projeto.
3. Crie um banco Firestore.
4. Registre um aplicativo Web.
5. Copie as configurações para `src/firebase.js`.
6. Para uma apresentação acadêmica simples, configure as regras do Firestore conforme o ambiente de teste da disciplina. Não publique chaves/regras inseguras em produção.

## 3. Coleções
produtos, pedidos, categorias, estoques, avaliacoes.

Cada tela possui:
- Create: cadastrar
- Read: listar
- Update: editar
- Delete: excluir

## 4. Requisito de 5 documentos
Cadastre pelo menos 5 documentos em cada coleção antes da apresentação.
Total mínimo: 25 documentos.

## 5. Explicação para apresentação
- React organiza a interface em componentes.
- Vite executa e empacota o projeto.
- useState guarda estados do formulário/lista.
- useEffect carrega os dados quando a coleção muda.
- addDoc cria documentos.
- getDocs lê documentos.
- updateDoc atualiza documentos.
- deleteDoc remove documentos.
- Firestore é o banco NoSQL.
